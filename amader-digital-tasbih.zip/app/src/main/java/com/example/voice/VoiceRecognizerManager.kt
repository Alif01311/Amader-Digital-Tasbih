package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceDetectionMode {
    AI_SPEECH_WORDS,   // Matches specific spoken Zikr words via Speech Recognizer
    VOICE_CHANT_BURST, // Detects vocal bursts / chants (ultra-fast, works 100% offline)
    HYBRID_AUTO        // Uses Speech Recognition with Vocal Burst backup
}

class VoiceRecognizerManager(
    private val context: Context,
    private val onPhraseCountDetected: (countDelta: Int, recognizedText: String) -> Unit
) {
    private val TAG = "VoiceRecognizerManager"
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _audioRms = MutableStateFlow(0f)
    val audioRms: StateFlow<Float> = _audioRms.asStateFlow()

    private val _currentSpokenText = MutableStateFlow("")
    val currentSpokenText: StateFlow<String> = _currentSpokenText.asStateFlow()

    private val _listeningStatus = MutableStateFlow("Ready to start")
    val listeningStatus: StateFlow<String> = _listeningStatus.asStateFlow()

    private val _voiceMode = MutableStateFlow(VoiceDetectionMode.HYBRID_AUTO)
    val voiceMode: StateFlow<VoiceDetectionMode> = _voiceMode.asStateFlow()

    private var targetKeywords: List<String> = emptyList()
    private var isDesiredActive = false
    private var matchesInCurrentUtterance = 0
    private var restartCount = 0

    // Voice energy burst detector for rhythmic recitation / fast chanting
    private var isVoiceBurstActive = false
    private var lastBurstTimeMs = 0L
    private var lastSpeechCountTimeMs = 0L

    init {
        initRecognizer()
    }

    fun setDetectionMode(mode: VoiceDetectionMode) {
        _voiceMode.value = mode
    }

    private fun initRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _listeningStatus.value = "Speech service unavailable; using vocal pulse detection"
            return
        }

        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(createListener())
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create SpeechRecognizer", e)
            _listeningStatus.value = "Microphone ready (Vocal Mode)"
        }
    }

    fun updateTargetKeywords(keywords: List<String>) {
        this.targetKeywords = keywords.map { it.trim().lowercase(Locale.ROOT) }
    }

    fun startListening() {
        isDesiredActive = true
        matchesInCurrentUtterance = 0
        _currentSpokenText.value = ""
        _listeningStatus.value = "Listening for your recitation..."
        startSpeechService()
    }

    fun stopListening() {
        isDesiredActive = false
        _isListening.value = false
        _audioRms.value = 0f
        _listeningStatus.value = "Voice counting paused"
        matchesInCurrentUtterance = 0
        mainHandler.removeCallbacksAndMessages(null)

        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping recognizer", e)
            }
        }
    }

    private fun startSpeechService() {
        if (!isDesiredActive) return

        mainHandler.post {
            try {
                if (speechRecognizer == null) {
                    initRecognizer()
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                    putExtra("android.speech.extra.DICTATION_MODE", true)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                }

                matchesInCurrentUtterance = 0
                speechRecognizer?.startListening(intent)
                _isListening.value = true
            } catch (e: Exception) {
                Log.e(TAG, "Error starting speech listener", e)
                scheduleRestart(400)
            }
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (!isDesiredActive) return
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({
            if (isDesiredActive) {
                restartCount++
                if (restartCount % 5 == 0) {
                    // Recreate instance to clear audio pipe
                    initRecognizer()
                }
                startSpeechService()
            }
        }, delayMs)
    }

    private fun createListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
                _listeningStatus.value = "Listening... Speak your Zikr"
            }

            override fun onBeginningOfSpeech() {
                _listeningStatus.value = "Voice detected..."
            }

            override fun onRmsChanged(rmsdB: Float) {
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                _audioRms.value = normalized

                // Check vocal burst counting if in CHANT_BURST or HYBRID mode
                handleVoiceRmsEnergy(normalized)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _audioRms.value = 0f
                _listeningStatus.value = "Processing recitation..."
            }

            override fun onError(error: Int) {
                _audioRms.value = 0f
                val errorMessage = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                    SpeechRecognizer.ERROR_CLIENT -> "Client restarting..."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                    SpeechRecognizer.ERROR_NETWORK -> "Network offline (using local mic)"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                    SpeechRecognizer.ERROR_NO_MATCH -> "Listening for your words..."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Busy, resetting..."
                    SpeechRecognizer.ERROR_SERVER -> "Server error"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Keep reciting..."
                    else -> "Listening active..."
                }

                Log.d(TAG, "SpeechRecognizer error: $error ($errorMessage)")
                _listeningStatus.value = errorMessage

                if (isDesiredActive) {
                    // For busy or client error, re-create after brief pause
                    if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
                        initRecognizer()
                        scheduleRestart(350L)
                    } else {
                        scheduleRestart(150L)
                    }
                }
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    processRecognizedUtterance(matches)
                }
                matchesInCurrentUtterance = 0

                if (isDesiredActive) {
                    scheduleRestart(100)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    processRecognizedUtterance(matches)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    private fun handleVoiceRmsEnergy(rms: Float) {
        val mode = _voiceMode.value
        val now = System.currentTimeMillis()

        // High volume threshold for active voice burst
        val thresholdHigh = 0.45f
        val thresholdLow = 0.20f
        val minIntervalBetweenBursts = 450L // Minimum time between phrases (max ~130 Zikr/min)

        if (rms >= thresholdHigh) {
            if (!isVoiceBurstActive && (now - lastBurstTimeMs > minIntervalBetweenBursts)) {
                isVoiceBurstActive = true
                lastBurstTimeMs = now

                // In VOICE_CHANT_BURST mode, directly count
                if (mode == VoiceDetectionMode.VOICE_CHANT_BURST) {
                    onPhraseCountDetected(1, "Vocal Chant")
                    _currentSpokenText.value = "Vocal Chanting Detected"
                }
                // In HYBRID_AUTO mode, if speech recognizer hasn't fired in > 1800ms of sustained speech
                else if (mode == VoiceDetectionMode.HYBRID_AUTO) {
                    if (now - lastSpeechCountTimeMs > 2200L && now - lastBurstTimeMs > 1200L) {
                        onPhraseCountDetected(1, "Chant Pulse")
                        _currentSpokenText.value = "Chant Sound Counted"
                    }
                }
            }
        } else if (rms < thresholdLow) {
            isVoiceBurstActive = false
        }
    }

    private fun processRecognizedUtterance(transcripts: List<String>) {
        if (targetKeywords.isEmpty()) return

        var bestTranscript = ""
        var maxOccurrences = 0

        // Check across all hypothesis transcripts
        for (text in transcripts) {
            val normalized = normalizeSpeechText(text)
            val count = countOccurrences(normalized, targetKeywords)
            if (count > maxOccurrences) {
                maxOccurrences = count
                bestTranscript = text
            }
        }

        if (bestTranscript.isBlank()) {
            bestTranscript = transcripts.firstOrNull() ?: ""
        }
        _currentSpokenText.value = bestTranscript

        if (maxOccurrences > matchesInCurrentUtterance) {
            val delta = maxOccurrences - matchesInCurrentUtterance
            matchesInCurrentUtterance = maxOccurrences
            lastSpeechCountTimeMs = System.currentTimeMillis()
            onPhraseCountDetected(delta, bestTranscript)
        }
    }

    private fun countOccurrences(transcript: String, keywords: List<String>): Int {
        var total = 0

        // Multi-word keywords (e.g. "subhan allah", "allahu akbar", "la ilaha illallah")
        val multiWordKeywords = keywords.filter { it.contains(" ") }
        var remainingTranscript = transcript

        for (multiWord in multiWordKeywords) {
            var index = 0
            while (index != -1 && remainingTranscript.isNotEmpty()) {
                index = remainingTranscript.indexOf(multiWord, index)
                if (index != -1) {
                    total++
                    val before = remainingTranscript.substring(0, index)
                    val after = remainingTranscript.substring(index + multiWord.length)
                    remainingTranscript = "$before ${" ".repeat(multiWord.length)} $after"
                    index += multiWord.length
                }
            }
        }

        // Single-word keywords
        val singleWordKeywords = keywords.filter { !it.contains(" ") }
        val remainingWords = remainingTranscript.split("\\s+".toRegex()).filter { it.isNotBlank() }

        for (word in remainingWords) {
            val matched = singleWordKeywords.any { keyword ->
                word == keyword ||
                (keyword.length >= 4 && (word.contains(keyword) || keyword.contains(word)))
            }
            if (matched) {
                total++
            }
        }

        return total
    }

    private fun normalizeSpeechText(input: String): String {
        return input.lowercase(Locale.ROOT)
            .replace("[.,!?;:\"'()\\-_/]".toRegex(), " ")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    fun destroy() {
        isDesiredActive = false
        mainHandler.removeCallbacksAndMessages(null)
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying speech recognizer", e)
        }
    }
}
