package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.TasbihViewModel
import com.example.ui.components.AddCustomDuaDialog
import com.example.ui.components.BottomControlsBar
import com.example.ui.components.CelebrationConfettiEffect
import com.example.ui.components.PhraseHeaderCard
import com.example.ui.components.PhraseSelectionBottomSheet
import com.example.ui.components.SettingsSheet
import com.example.ui.components.StatsAndHistorySheet
import com.example.ui.components.TargetCelebrationDialog
import com.example.ui.components.TargetSelectionDialog
import com.example.ui.components.TasbihDial
import com.example.ui.components.VoiceWaveVisualizer
import com.example.ui.theme.EmeraldDeepDark
import com.example.ui.theme.EmeraldSurfaceDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: TasbihViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme(darkTheme = true) {
                TasbihMainScreen(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (viewModel.uiState.value.isVoiceMode && !viewModel.uiState.value.isVoiceListening) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                viewModel.startVoiceListening()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        viewModel.stopVoiceListening()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasbihMainScreen(viewModel: TasbihViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var showPhraseSheet by remember { mutableStateOf(false) }
    var showTargetDialog by remember { mutableStateOf(false) }
    var showAddCustomDialog by remember { mutableStateOf(false) }
    var showHistorySheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    // Audio Permission Launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.toggleVoiceMode(true)
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Microphone active! Speak your Zikr hands-free.")
            }
        } else {
            viewModel.toggleVoiceMode(false)
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Microphone permission denied. Switched to manual tap mode.")
            }
        }
    }

    // Check permission when switching to voice mode
    fun handleVoiceModeToggle(enable: Boolean) {
        if (enable) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

            if (hasPermission) {
                viewModel.toggleVoiceMode(true)
            } else {
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        } else {
            viewModel.toggleVoiceMode(false)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = EmeraldDeepDark,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(GoldPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "☪",
                                fontSize = 16.sp,
                                color = GoldPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Amader Digital Tasbih",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            Text(
                                text = "Voice & Hands-Free Counter",
                                fontSize = 10.sp,
                                color = GoldLight
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { showPhraseSheet = true },
                        modifier = Modifier.testTag("top_bar_phrases_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FormatListBulleted,
                            contentDescription = "All Duas",
                            tint = GoldPrimary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showHistorySheet = true },
                        modifier = Modifier.testTag("top_bar_history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.BarChart,
                            contentDescription = "History",
                            tint = GoldPrimary
                        )
                    }

                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier.testTag("top_bar_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = TextSecondaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = EmeraldDeepDark
                ),
                modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars)
            )
        },
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                BottomControlsBar(
                    isVoiceMode = uiState.isVoiceMode,
                    targetCount = uiState.targetCount,
                    onToggleMode = { handleVoiceModeToggle(it) },
                    onOpenTargetPicker = { showTargetDialog = true },
                    onResetCount = { viewModel.resetCount(saveSession = true) },
                    onOpenHistory = { showHistorySheet = true },
                    onOpenSettings = { showSettingsSheet = true }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Active Dua Phrase Card
            PhraseHeaderCard(
                phrase = uiState.activePhrase,
                onOpenPhrasePicker = { showPhraseSheet = true }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Tasbih Beads Dial & Digital Counter
            TasbihDial(
                currentCount = uiState.currentCount,
                targetCount = uiState.targetCount,
                isVoiceMode = uiState.isVoiceMode,
                isVoiceListening = uiState.isVoiceListening,
                onDialTap = {
                    viewModel.incrementCount(delta = 1, isFromVoice = false)
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Voice Wave Visualizer when Voice Mode is enabled
            if (uiState.isVoiceMode) {
                VoiceWaveVisualizer(
                    isVoiceMode = uiState.isVoiceMode,
                    isListening = uiState.isVoiceListening,
                    voiceDetectionMode = uiState.voiceDetectionMode,
                    audioRms = uiState.audioRms,
                    statusMessage = uiState.voiceStatusMessage,
                    lastTranscript = uiState.lastSpokenTranscript,
                    onToggleListening = {
                        if (uiState.isVoiceListening) {
                            viewModel.stopVoiceListening()
                        } else {
                            viewModel.startVoiceListening()
                        }
                    },
                    onSelectMode = { viewModel.setVoiceDetectionMode(it) }
                )
            } else {
                // Helpful hint card for Tap Mode
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(CircleShape)
                        .background(EmeraldSurfaceDark)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Tap dial above or switch to Voice Mode for hands-free counting",
                        fontSize = 12.sp,
                        color = TextSecondaryDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    // Modal Sheets and Dialogs
    if (showPhraseSheet) {
        PhraseSelectionBottomSheet(
            allPhrases = uiState.allPhrases,
            selectedPhrase = uiState.activePhrase,
            onSelectPhrase = { viewModel.selectPhrase(it) },
            onOpenAddCustomDialog = { showAddCustomDialog = true },
            onDeleteCustomPhrase = { viewModel.deleteCustomPhrase(it) },
            onDismiss = { showPhraseSheet = false }
        )
    }

    if (showTargetDialog) {
        TargetSelectionDialog(
            currentTarget = uiState.targetCount,
            onSelectTarget = { viewModel.setTargetCount(it) },
            onDismiss = { showTargetDialog = false }
        )
    }

    if (showAddCustomDialog) {
        AddCustomDuaDialog(
            onDismiss = { showAddCustomDialog = false },
            onSave = { title, arabic, transliteration, translation, target, keywords ->
                viewModel.addCustomPhrase(
                    title = title,
                    arabicText = arabic,
                    transliteration = transliteration,
                    translation = translation,
                    target = target,
                    keywords = keywords
                )
            }
        )
    }

    if (uiState.showTargetCelebration) {
        TargetCelebrationDialog(
            phrase = uiState.activePhrase,
            completedCount = uiState.currentCount,
            targetCount = uiState.targetCount,
            onContinueNextCycle = { viewModel.continueToNextCycle() },
            onSwitchNextDua = { viewModel.switchNextRecommendedDua() },
            onReset = { viewModel.resetCount(saveSession = true) },
            onDismiss = { viewModel.dismissCelebration() }
        )
    }

    if (showHistorySheet) {
        StatsAndHistorySheet(
            todayCount = uiState.todayCount,
            totalCount = uiState.totalLifetimeCount,
            sessions = uiState.recentSessions,
            onClearHistory = { viewModel.clearHistory() },
            onDismiss = { showHistorySheet = false }
        )
    }

    if (showSettingsSheet) {
        SettingsSheet(
            soundEnabled = uiState.soundEnabled,
            vibrationEnabled = uiState.vibrationEnabled,
            voiceDetectionMode = uiState.voiceDetectionMode,
            onToggleSound = { viewModel.toggleSound(it) },
            onToggleVibration = { viewModel.toggleVibration(it) },
            onSelectVoiceMode = { viewModel.setVoiceDetectionMode(it) },
            onTestCelebrationSound = { viewModel.testCelebrationSound() },
            onDismiss = { showSettingsSheet = false }
        )
    }

    if (uiState.showTargetCelebration) {
        CelebrationConfettiEffect(modifier = Modifier.fillMaxSize())
    }
    }
}
