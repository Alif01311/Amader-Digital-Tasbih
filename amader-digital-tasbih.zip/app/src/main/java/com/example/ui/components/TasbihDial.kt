package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldBorder
import com.example.ui.theme.EmeraldCardDark
import com.example.ui.theme.EmeraldDeepDark
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.MintGreen
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun TasbihDial(
    currentCount: Int,
    targetCount: Int,
    isVoiceMode: Boolean,
    isVoiceListening: Boolean,
    onDialTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Pulse animation on each increment
    val countScale = remember { Animatable(1f) }
    LaunchedEffect(currentCount) {
        if (currentCount > 0) {
            countScale.animateTo(1.15f, animationSpec = spring(dampingRatio = 0.4f, stiffness = 600f))
            countScale.animateTo(1f, animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f))
        }
    }

    // Gentle breathing halo for active listening
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val listeningHaloScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isVoiceMode && isVoiceListening) 1.05f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "halo"
    )

    val progress = if (targetCount > 0) {
        (currentCount % targetCount).toFloat() / targetCount.toFloat()
    } else {
        ((currentCount % 100).toFloat() / 100f)
    }

    Box(
        modifier = modifier
            .size(280.dp)
            .scale(listeningHaloScale),
        contentAlignment = Alignment.Center
    ) {
        // Outer decorative ring and beads canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 10.dp.toPx()
            val diameter = size.minDimension - strokeWidth * 2
            val radius = diameter / 2f
            val center = Offset(size.width / 2f, size.height / 2f)

            // Background track ring
            drawCircle(
                color = Color(0xFF14271E),
                radius = radius,
                center = center,
                style = Stroke(width = strokeWidth)
            )

            // Animated Progress Arc
            val sweepAngle = (progress * 360f).coerceIn(0f, 360f)
            if (sweepAngle > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(GoldDark, GoldPrimary, MintGreen, GoldLight, GoldDark),
                        center = center
                    ),
                    startAngle = -90f,
                    sweepAngle = sweepAngle,
                    useCenter = false,
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = Size(diameter, diameter),
                    style = Stroke(width = strokeWidth + 2f, cap = StrokeCap.Round)
                )
            }

            // Draw 33 bead markers along the circumference
            val totalBeads = 33
            val currentBeadIndex = if (targetCount > 0) {
                ((currentCount % targetCount) * totalBeads / targetCount).coerceIn(0, totalBeads)
            } else {
                (currentCount % totalBeads)
            }

            for (i in 0 until totalBeads) {
                val angleDeg = -90f + (i * (360f / totalBeads))
                val angleRad = Math.toRadians(angleDeg.toDouble())
                val beadRadiusDistance = radius - (strokeWidth * 1.6f)
                val bx = center.x + (beadRadiusDistance * cos(angleRad)).toFloat()
                val by = center.y + (beadRadiusDistance * sin(angleRad)).toFloat()

                // Divider marker at bead 11 and 22
                val isDivider = (i == 11 || i == 22 || i == 0)
                val isFilled = i < currentBeadIndex
                val beadDotRadius = if (isDivider) 5.dp.toPx() else 3.5.dp.toPx()

                val beadColor = when {
                    isFilled -> GoldLight
                    isDivider -> GoldDark.copy(alpha = 0.8f)
                    else -> Color(0xFF233F31)
                }

                drawCircle(
                    color = beadColor,
                    radius = beadDotRadius,
                    center = Offset(bx, by)
                )
            }
        }

        // Inner Touchable Circular Button
        Box(
            modifier = Modifier
                .size(200.dp)
                .shadow(16.dp, CircleShape, spotColor = GoldPrimary.copy(alpha = 0.25f))
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF1E382B),
                            Color(0xFF11221A),
                            EmeraldDeepDark
                        )
                    )
                )
                .border(2.dp, GoldPrimary.copy(alpha = 0.4f), CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(color = GoldPrimary, bounded = true),
                    onClick = onDialTap
                )
                .testTag("tasbih_count_dial"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .padding(16.dp)
                    .scale(countScale.value)
            ) {
                // Mode indicator badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(
                            if (isVoiceMode && isVoiceListening) MintGreen.copy(alpha = 0.2f)
                            else GoldPrimary.copy(alpha = 0.15f)
                        )
                        .padding(horizontal = 10.dp, vertical = 3.dp)
                ) {
                    Icon(
                        imageVector = if (isVoiceMode) Icons.Default.Mic else Icons.Default.TouchApp,
                        contentDescription = if (isVoiceMode) "Voice counting" else "Tap mode",
                        tint = if (isVoiceMode && isVoiceListening) MintGreen else GoldPrimary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.size(4.dp))
                    Text(
                        text = if (isVoiceMode) {
                            if (isVoiceListening) "VOICE LISTENING" else "VOICE READY"
                        } else "TAP TO COUNT",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = if (isVoiceMode && isVoiceListening) MintGreen else GoldPrimary
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Big Digital Count Number
                Text(
                    text = currentCount.toString(),
                    fontSize = if (currentCount > 999) 44.sp else 54.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.SansSerif,
                    color = Color(0xFFFBF8EE),
                    modifier = Modifier.testTag("tasbih_current_count")
                )

                // Target Milestone
                Text(
                    text = if (targetCount > 0) "/ $targetCount" else "/ ∞",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = GoldLight.copy(alpha = 0.85f),
                    letterSpacing = 1.sp
                )
            }
        }
    }
}
