package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldBorder
import com.example.ui.theme.EmeraldCardDark
import com.example.ui.theme.EmeraldDeepDark
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.MintDark
import com.example.ui.theme.MintGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondaryDark

@Composable
fun BottomControlsBar(
    isVoiceMode: Boolean,
    targetCount: Int,
    onToggleMode: (Boolean) -> Unit,
    onOpenTargetPicker: () -> Unit,
    onResetCount: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(EmeraldCardDark.copy(alpha = 0.95f))
            .border(1.dp, EmeraldBorder, RoundedCornerShape(24.dp))
            .padding(14.dp)
    ) {
        // Mode Switch Segmented Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(EmeraldDeepDark)
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Voice Mode tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isVoiceMode) GoldPrimary else Color.Transparent)
                    .clickable { onToggleMode(true) }
                    .padding(vertical = 10.dp)
                    .testTag("mode_switch_voice"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Hands-free Voice Mode",
                        tint = if (isVoiceMode) EmeraldDeepDark else TextSecondaryDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Voice Counting",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isVoiceMode) EmeraldDeepDark else TextSecondaryDark
                    )
                }
            }

            // Manual Tap Mode tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (!isVoiceMode) GoldPrimary else Color.Transparent)
                    .clickable { onToggleMode(false) }
                    .padding(vertical = 10.dp)
                    .testTag("mode_switch_tap"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = "Manual Tap Mode",
                        tint = if (!isVoiceMode) EmeraldDeepDark else TextSecondaryDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Manual Tap",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (!isVoiceMode) EmeraldDeepDark else TextSecondaryDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Secondary Actions Row: Target, Reset, History, Settings
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Target Selector Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF142B20))
                    .border(1.dp, EmeraldBorder, RoundedCornerShape(12.dp))
                    .clickable(onClick = onOpenTargetPicker)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .testTag("target_picker_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Target: ",
                        fontSize = 12.sp,
                        color = TextSecondaryDark
                    )
                    Text(
                        text = if (targetCount > 0) "$targetCount" else "Unlimited (∞)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Reset Button
                IconButton(
                    onClick = onResetCount,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF221714))
                        .testTag("tasbih_reset_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset count",
                        tint = Color(0xFFFFB4AB),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // History & Stats Button
                IconButton(
                    onClick = onOpenHistory,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF142B20))
                        .testTag("tasbih_history_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.BarChart,
                        contentDescription = "History and Statistics",
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Settings Button
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF142B20))
                        .testTag("tasbih_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = TextSecondaryDark,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
