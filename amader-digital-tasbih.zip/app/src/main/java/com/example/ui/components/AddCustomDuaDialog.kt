package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldBorder
import com.example.ui.theme.EmeraldCardDark
import com.example.ui.theme.EmeraldDeepDark
import com.example.ui.theme.EmeraldSurfaceDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.MintGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun AddCustomDuaDialog(
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        arabic: String,
        transliteration: String,
        translation: String,
        target: Int,
        keywords: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var arabicText by remember { mutableStateOf("") }
    var transliteration by remember { mutableStateOf("") }
    var translation by remember { mutableStateOf("") }
    var targetText by remember { mutableStateOf("33") }
    var keywordsText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val textFieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = GoldPrimary,
        unfocusedBorderColor = EmeraldBorder,
        focusedLabelColor = GoldLight,
        unfocusedLabelColor = TextSecondaryDark,
        cursorColor = GoldPrimary,
        focusedTextColor = TextPrimaryDark,
        unfocusedTextColor = TextPrimaryDark
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = EmeraldSurfaceDark,
        title = {
            Text(
                text = "Add Custom Zikr / Dua",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryDark
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Type any Dua or phrase to count hands-free via real-time speech recognition.",
                    fontSize = 12.sp,
                    color = TextSecondaryDark
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        if (keywordsText.isEmpty()) keywordsText = it
                    },
                    label = { Text("Dua Title / Name *") },
                    placeholder = { Text("e.g. Ya Hayyu Ya Qayyum") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_dua_title_input"),
                    colors = textFieldColors,
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = arabicText,
                    onValueChange = { arabicText = it },
                    label = { Text("Arabic Text (Optional)") },
                    placeholder = { Text("e.g. يَا حَيُّ يَا قَيُّومُ") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_dua_arabic_input"),
                    colors = textFieldColors,
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = translation,
                    onValueChange = { translation = it },
                    label = { Text("Meaning / Translation (Optional)") },
                    placeholder = { Text("e.g. O Ever-Living, O Self-Sustaining") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = textFieldColors,
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = keywordsText,
                    onValueChange = { keywordsText = it },
                    label = { Text("Speech Keywords (Comma separated) *") },
                    placeholder = { Text("e.g. ya hayyu, ya qayyum, hayyu") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_dua_keywords_input"),
                    colors = textFieldColors,
                    supportingText = {
                        Text(
                            text = "Words the speech counter listens for to increment",
                            fontSize = 11.sp,
                            color = MintGreen
                        )
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = targetText,
                    onValueChange = { targetText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Target Goal Count") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_dua_target_input"),
                    colors = textFieldColors,
                    singleLine = true
                )

                if (errorMessage.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = errorMessage,
                        fontSize = 12.sp,
                        color = Color(0xFFFFB4AB)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) {
                        errorMessage = "Please enter a title or phrase name."
                        return@Button
                    }
                    val target = targetText.toIntOrNull() ?: 33
                    val kw = if (keywordsText.isNotBlank()) keywordsText else title
                    onSave(
                        title.trim(),
                        arabicText.trim(),
                        transliteration.ifBlank { title.trim() },
                        translation.trim(),
                        target,
                        kw
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldPrimary,
                    contentColor = EmeraldDeepDark
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("custom_dua_save_button")
            ) {
                Text(text = "Save Zikr", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Cancel", color = TextSecondaryDark)
            }
        }
    )
}
