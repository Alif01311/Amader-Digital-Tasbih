package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Islamic Emerald & Gold Luxury Palette
val EmeraldDeepDark = Color(0xFF08120E)
val EmeraldSurfaceDark = Color(0xFF0F1E17)
val EmeraldCardDark = Color(0xFF162B21)
val EmeraldCardLighter = Color(0xFF1D372B)
val EmeraldBorder = Color(0xFF284D3C)

val GoldPrimary = Color(0xFFDFB15B)
val GoldLight = Color(0xFFF3D289)
val GoldDark = Color(0xFFB38933)
val GoldContainer = Color(0xFF332711)

val MintGreen = Color(0xFF34D399)
val MintSoft = Color(0xFF6EE7B7)
val MintDark = Color(0xFF064E3B)

val TextPrimaryDark = Color(0xFFF3F7F5)
val TextSecondaryDark = Color(0xFF9DB5A9)
val TextMuted = Color(0xFF658073)

// Light Theme Palette
val EmeraldPrimaryLight = Color(0xFF135A3D)
val EmeraldBackgroundLight = Color(0xFFF6F9F7)
val EmeraldSurfaceLight = Color(0xFFFFFFFF)
val EmeraldCardLight = Color(0xFFEBF3EE)
val EmeraldBorderLight = Color(0xFFCEE0D7)
val TextPrimaryLight = Color(0xFF0B1F16)
val TextSecondaryLight = Color(0xFF3E5C4E)
