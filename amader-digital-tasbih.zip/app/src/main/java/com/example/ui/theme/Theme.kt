package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = EmeraldDeepDark,
    primaryContainer = GoldContainer,
    onPrimaryContainer = GoldLight,
    secondary = MintGreen,
    onSecondary = MintDark,
    secondaryContainer = EmeraldCardLighter,
    onSecondaryContainer = MintSoft,
    tertiary = GoldLight,
    onTertiary = EmeraldDeepDark,
    background = EmeraldDeepDark,
    onBackground = TextPrimaryDark,
    surface = EmeraldSurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = EmeraldCardDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = EmeraldBorder,
    outlineVariant = EmeraldCardLighter
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimaryLight,
    onPrimary = Color.White,
    primaryContainer = EmeraldCardLight,
    onPrimaryContainer = EmeraldPrimaryLight,
    secondary = GoldDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFBF4E2),
    onSecondaryContainer = GoldDark,
    tertiary = MintDark,
    background = EmeraldBackgroundLight,
    onBackground = TextPrimaryLight,
    surface = EmeraldSurfaceLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = EmeraldCardLight,
    onSurfaceVariant = TextSecondaryLight,
    outline = EmeraldBorderLight,
    outlineVariant = EmeraldBorderLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to Islamic high-contrast dark theme for prayer/tasbih
    dynamicColor: Boolean = false, // Keep tailored Islamic jewel colors
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
