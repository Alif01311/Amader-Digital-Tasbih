package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldBorder
import com.example.ui.theme.EmeraldCardDark
import com.example.ui.theme.EmeraldDeepDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.MintDark
import com.example.ui.theme.MintGreen
import com.example.ui.theme.MintSoft
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondaryDark
import com.example.voice.VoiceDetectionMode

@Composable
fun VoiceWaveVisualizer(
    isVoiceMode: Boolean,
    isListening: Boolean,
    voiceDetectionMode: VoiceDetectionMode,
    audioRms: Float,
    statusMessage: String,
    lastTranscript: String,
    onToggleListening: () -> Unit,
    onSelectMode: (VoiceDetectionMode) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!isVoiceMode) return

    val animatedRms by animateFloatAsState(
        targetValue = if (isListening) audioRms else 0f,
        animationSpec = tween(120),
        label = "rms"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(EmeraldCardDark.copy(alpha = 0.85f))
            .border(1.dp, EmeraldBorder, RoundedCornerShape(20.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isListening) MintGreen.copy(alpha = 0.2f) else Color(0xFF24362E)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicOff,
                        contentDescription = "Mic Status",
                        tint = if (isListening) MintGreen else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = if (isListening) "Speech Counter Active" else "Speech Counter Paused",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isListening) MintSoft else TextSecondaryDark
                    )
                    Text(
                        text = statusMessage,
                        fontSize = 11.sp,
                        color = TextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Start/Pause action button
            FilledTonalButton(
                onClick = onToggleListening,
                modifier = Modifier
                    .height(34.dp)
                    .testTag("voice_toggle_listening_button"),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = if (isListening) Color(0xFF2A1C16) else MintDark,
                    contentColor = if (isListening) Color(0xFFFFB4AB) else MintSoft
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (isListening) "Pause Mic" else "Resume",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Sound Wave Visualizer Bars
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val barCount = 13
            val baseHeights = listOf(5f, 10f, 16f, 24f, 14f, 26f, 20f, 26f, 14f, 24f, 16f, 10f, 5f)

            for (i in 0 until barCount) {
                val scale = if (isListening) {
                    (0.2f + (animatedRms * 1.6f) * (0.6f + (i % 3) * 0.2f)).coerceIn(0.15f, 1.2f)
                } else 0.15f

                val barHeight = (baseHeights[i] * scale).coerceAtLeast(3f)

                Box(
                    modifier = Modifier
                        .padding(horizontal = 2.dp)
                        .width(4.dp)
                        .height(barHeight.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(
                            if (isListening) {
                                if (animatedRms > 0.35f) GoldPrimary else MintGreen
                            } else Color(0xFF254234)
                        )
                )
            }
        }

        // Live recognized utterance text
        AnimatedVisibility(
            visible = lastTranscript.isNotBlank(),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Row(
                modifier = Modifier
                    .padding(top = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F261C))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Heard: \"$lastTranscript\"",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = GoldPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Mic Sensitivity / Mode Selector Pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(EmeraldDeepDark)
                .padding(2.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val modes = listOf(
                VoiceDetectionMode.HYBRID_AUTO to "Auto Hybrid",
                VoiceDetectionMode.AI_SPEECH_WORDS to "Words AI",
                VoiceDetectionMode.VOICE_CHANT_BURST to "Chant Beat"
            )

            modes.forEach { (mode, label) ->
                val isSelected = voiceDetectionMode == mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) GoldPrimary else Color.Transparent)
                        .clickable { onSelectMode(mode) }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) EmeraldDeepDark else TextMuted
                    )
                }
            }
        }
    }
}
