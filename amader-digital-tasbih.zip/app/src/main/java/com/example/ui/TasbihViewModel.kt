package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.TasbihSessionEntity
import com.example.data.repository.TasbihRepository
import com.example.model.DuaPhrase
import com.example.util.FeedbackManager
import com.example.voice.VoiceDetectionMode
import com.example.voice.VoiceRecognizerManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class TasbihUiState(
    val activePhrase: DuaPhrase = DuaPhrase.PRESET_PHRASES.first(),
    val currentCount: Int = 0,
    val targetCount: Int = 33,
    val isVoiceMode: Boolean = true,
    val isVoiceListening: Boolean = false,
    val voiceDetectionMode: VoiceDetectionMode = VoiceDetectionMode.HYBRID_AUTO,
    val audioRms: Float = 0f,
    val lastSpokenTranscript: String = "",
    val voiceStatusMessage: String = "Ready to start",
    val vibrationEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val showTargetCelebration: Boolean = false,
    val todayCount: Int = 0,
    val totalLifetimeCount: Int = 0,
    val customPhrases: List<DuaPhrase> = emptyList(),
    val allPhrases: List<DuaPhrase> = DuaPhrase.PRESET_PHRASES,
    val recentSessions: List<TasbihSessionEntity> = emptyList()
)

class TasbihViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TasbihRepository
    private val feedbackManager: FeedbackManager
    private val voiceManager: VoiceRecognizerManager

    private val _uiState = MutableStateFlow(TasbihUiState())
    val uiState: StateFlow<TasbihUiState> = _uiState.asStateFlow()

    private var sessionStartTime = System.currentTimeMillis()
    private var lastCelebratedTarget = -1

    init {
        val database = AppDatabase.getInstance(application)
        repository = TasbihRepository(database.tasbihDao())
        feedbackManager = FeedbackManager(application)

        voiceManager = VoiceRecognizerManager(application) { delta, transcript ->
            handleVoiceMatch(delta, transcript)
        }

        // Initialize keywords with first preset
        voiceManager.updateTargetKeywords(_uiState.value.activePhrase.matchKeywords)

        // Observe custom phrases and combine with presets
        viewModelScope.launch {
            repository.customPhrases.collect { entities ->
                val custom = entities.map { it.toDuaPhrase() }
                val combined = DuaPhrase.PRESET_PHRASES + custom
                _uiState.value = _uiState.value.copy(
                    customPhrases = custom,
                    allPhrases = combined
                )
            }
        }

        // Observe total count
        viewModelScope.launch {
            repository.totalCount.collect { total ->
                _uiState.value = _uiState.value.copy(totalLifetimeCount = total ?: 0)
            }
        }

        // Observe today's count
        viewModelScope.launch {
            repository.getTodayCount().collect { today ->
                _uiState.value = _uiState.value.copy(todayCount = today ?: 0)
            }
        }

        // Observe recent sessions
        viewModelScope.launch {
            repository.allSessions.collect { sessions ->
                _uiState.value = _uiState.value.copy(recentSessions = sessions)
            }
        }

        // Observe voice manager states
        viewModelScope.launch {
            voiceManager.isListening.collect { listening ->
                _uiState.value = _uiState.value.copy(isVoiceListening = listening)
            }
        }

        viewModelScope.launch {
            voiceManager.audioRms.collect { rms ->
                _uiState.value = _uiState.value.copy(audioRms = rms)
            }
        }

        viewModelScope.launch {
            voiceManager.currentSpokenText.collect { text ->
                _uiState.value = _uiState.value.copy(lastSpokenTranscript = text)
            }
        }

        viewModelScope.launch {
            voiceManager.listeningStatus.collect { status ->
                _uiState.value = _uiState.value.copy(voiceStatusMessage = status)
            }
        }
    }

    private fun handleVoiceMatch(delta: Int, transcript: String) {
        if (delta <= 0) return
        incrementCount(delta = delta, isFromVoice = true)
    }

    fun incrementCount(delta: Int = 1, isFromVoice: Boolean = false) {
        val current = _uiState.value.currentCount
        val target = _uiState.value.targetCount
        val newCount = current + delta

        feedbackManager.triggerCountFeedback(
            vibrationEnabled = _uiState.value.vibrationEnabled,
            soundEnabled = _uiState.value.soundEnabled
        )

        val targetReached = target > 0 && newCount >= target && current < target
        if (targetReached && lastCelebratedTarget != target) {
            lastCelebratedTarget = target
            feedbackManager.triggerTargetReachedFeedback(
                vibrationEnabled = _uiState.value.vibrationEnabled,
                soundEnabled = _uiState.value.soundEnabled
            )
        }

        _uiState.value = _uiState.value.copy(
            currentCount = newCount,
            showTargetCelebration = targetReached
        )

        // Save session incrementally or periodically
        viewModelScope.launch {
            val duration = (System.currentTimeMillis() - sessionStartTime) / 1000
            repository.saveSession(
                phraseId = _uiState.value.activePhrase.id,
                phraseTitle = _uiState.value.activePhrase.title,
                count = delta,
                target = target,
                mode = if (isFromVoice) "VOICE" else "MANUAL",
                durationSeconds = duration
            )
        }
    }

    fun resetCount(saveSession: Boolean = true) {
        val current = _uiState.value.currentCount
        if (saveSession && current > 0) {
            val duration = (System.currentTimeMillis() - sessionStartTime) / 1000
            viewModelScope.launch {
                repository.saveSession(
                    phraseId = _uiState.value.activePhrase.id,
                    phraseTitle = _uiState.value.activePhrase.title,
                    count = 0, // already recorded incrementally
                    target = _uiState.value.targetCount,
                    mode = if (_uiState.value.isVoiceMode) "VOICE" else "MANUAL",
                    durationSeconds = duration
                )
            }
        }
        sessionStartTime = System.currentTimeMillis()
        lastCelebratedTarget = -1
        _uiState.value = _uiState.value.copy(
            currentCount = 0,
            showTargetCelebration = false
        )
    }

    fun selectPhrase(phrase: DuaPhrase) {
        val current = _uiState.value.currentCount
        if (current > 0) {
            resetCount(saveSession = true)
        }
        voiceManager.updateTargetKeywords(phrase.matchKeywords)
        _uiState.value = _uiState.value.copy(
            activePhrase = phrase,
            targetCount = phrase.defaultTarget,
            currentCount = 0,
            showTargetCelebration = false
        )
    }

    fun setTargetCount(target: Int) {
        lastCelebratedTarget = -1
        _uiState.value = _uiState.value.copy(
            targetCount = target,
            showTargetCelebration = false
        )
    }

    fun toggleVoiceMode(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(isVoiceMode = enabled)
        if (enabled) {
            voiceManager.startListening()
        } else {
            voiceManager.stopListening()
        }
    }

    fun setVoiceDetectionMode(mode: VoiceDetectionMode) {
        voiceManager.setDetectionMode(mode)
        _uiState.value = _uiState.value.copy(voiceDetectionMode = mode)
    }

    fun startVoiceListening() {
        voiceManager.startListening()
    }

    fun stopVoiceListening() {
        voiceManager.stopListening()
    }

    fun toggleVibration(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(vibrationEnabled = enabled)
    }

    fun toggleSound(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(soundEnabled = enabled)
    }

    fun dismissCelebration() {
        _uiState.value = _uiState.value.copy(showTargetCelebration = false)
    }

    fun continueToNextCycle() {
        val current = _uiState.value.currentCount
        val target = _uiState.value.targetCount
        val newTarget = if (target > 0) target + _uiState.value.activePhrase.defaultTarget else 0
        lastCelebratedTarget = -1
        _uiState.value = _uiState.value.copy(
            targetCount = newTarget,
            showTargetCelebration = false
        )
    }

    fun switchNextRecommendedDua() {
        val active = _uiState.value.activePhrase.id
        val next = when (active) {
            "subhanallah" -> DuaPhrase.PRESET_PHRASES.find { it.id == "alhamdulillah" }
            "alhamdulillah" -> DuaPhrase.PRESET_PHRASES.find { it.id == "allahu_akbar" }
            "allahu_akbar" -> DuaPhrase.PRESET_PHRASES.find { it.id == "la_ilaha_illallah" }
            else -> DuaPhrase.PRESET_PHRASES.first()
        }
        if (next != null) {
            selectPhrase(next)
        }
    }

    fun addCustomPhrase(
        title: String,
        arabicText: String,
        transliteration: String,
        translation: String,
        target: Int,
        keywords: String
    ) {
        viewModelScope.launch {
            repository.addCustomPhrase(
                title = title,
                arabicText = arabicText,
                transliteration = transliteration,
                translation = translation,
                target = target,
                keywords = keywords
            )
        }
    }

    fun deleteCustomPhrase(phrase: DuaPhrase) {
        val idLong = phrase.id.removePrefix("custom_").toLongOrNull() ?: return
        viewModelScope.launch {
            repository.deleteCustomPhrase(idLong)
            if (_uiState.value.activePhrase.id == phrase.id) {
                selectPhrase(DuaPhrase.PRESET_PHRASES.first())
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun testCelebrationSound() {
        feedbackManager.triggerTargetReachedFeedback(
            vibrationEnabled = _uiState.value.vibrationEnabled,
            soundEnabled = true
        )
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
        feedbackManager.release()
    }
}
