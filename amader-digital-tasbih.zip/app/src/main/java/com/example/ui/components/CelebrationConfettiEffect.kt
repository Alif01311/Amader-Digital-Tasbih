package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private data class ConfettiParticle(
    val initialX: Float,
    val initialY: Float,
    val vx: Float,
    val vy: Float,
    val rotationSpeed: Float,
    val size: Float,
    val color: Color,
    val isStar: Boolean
)

@Composable
fun CelebrationConfettiEffect(
    modifier: Modifier = Modifier
) {
    val progress = remember { Animatable(0f) }

    val particles = remember {
        val colors = listOf(
            Color(0xFFDFB15B), // Gold
            Color(0xFFF3D289), // Light Gold
            Color(0xFF34D399), // Mint Green
            Color(0xFF6EE7B7), // Soft Mint
            Color(0xFFFFFFFF), // White Sparkle
            Color(0xFFFFD700)  // Bright Gold
        )
        List(75) {
            val angle = Random.nextFloat() * 2f * Math.PI.toFloat()
            val speed = Random.nextFloat() * 650f + 250f
            ConfettiParticle(
                initialX = 0.5f,
                initialY = 0.45f,
                vx = cos(angle) * speed,
                vy = (sin(angle) * speed) - 300f, // initial upward blast
                rotationSpeed = Random.nextFloat() * 720f - 360f,
                size = Random.nextFloat() * 12f + 8f,
                color = colors.random(),
                isStar = Random.nextBoolean()
            )
        }
    }

    LaunchedEffect(Unit) {
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 3200, easing = LinearEasing)
        )
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val t = progress.value
        val gravity = 900f

        particles.forEach { p ->
            val cx = size.width * p.initialX + (p.vx * t)
            val cy = size.height * p.initialY + (p.vy * t) + (0.5f * gravity * t * t)
            val currentRotation = p.rotationSpeed * t
            val alpha = (1f - (t * 0.9f)).coerceIn(0f, 1f)

            if (cy in -50f..(size.height + 50f) && cx in -50f..(size.width + 50f)) {
                rotate(degrees = currentRotation, pivot = Offset(cx, cy)) {
                    if (p.isStar) {
                        // Draw 4-point diamond star
                        val half = p.size / 2f
                        val path = Path().apply {
                            moveTo(cx, cy - half * 1.5f)
                            lineTo(cx + half * 0.5f, cy - half * 0.5f)
                            lineTo(cx + half * 1.5f, cy)
                            lineTo(cx + half * 0.5f, cy + half * 0.5f)
                            lineTo(cx, cy + half * 1.5f)
                            lineTo(cx - half * 0.5f, cy + half * 0.5f)
                            lineTo(cx - half * 1.5f, cy)
                            lineTo(cx - half * 0.5f, cy - half * 0.5f)
                            close()
                        }
                        drawPath(path = path, color = p.color.copy(alpha = alpha))
                    } else {
                        // Draw festive rectangular ribbon
                        drawRect(
                            color = p.color.copy(alpha = alpha),
                            topLeft = Offset(cx - p.size / 2, cy - p.size / 4),
                            size = Size(p.size, p.size * 0.6f)
                        )
                    }
                }
            }
        }
    }
}
