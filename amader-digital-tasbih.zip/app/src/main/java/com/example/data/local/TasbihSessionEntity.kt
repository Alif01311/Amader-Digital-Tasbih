package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasbih_sessions")
data class TasbihSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val phraseId: String,
    val phraseTitle: String,
    val count: Int,
    val target: Int,
    val mode: String, // "VOICE" or "MANUAL"
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Long = 0
)
