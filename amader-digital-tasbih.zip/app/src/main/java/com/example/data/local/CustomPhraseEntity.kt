package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.DuaPhrase

@Entity(tableName = "custom_phrases")
data class CustomPhraseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val arabicText: String = "",
    val transliteration: String = "",
    val translation: String = "",
    val target: Int = 33,
    val keywords: String = "", // Comma-separated
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toDuaPhrase(): DuaPhrase {
        val keywordList = keywords.split(",")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .toMutableList()
        if (title.isNotBlank()) keywordList.add(title.trim().lowercase())
        if (transliteration.isNotBlank()) keywordList.add(transliteration.trim().lowercase())

        return DuaPhrase(
            id = "custom_$id",
            title = title,
            arabicText = arabicText.ifBlank { "ذِكْرٌ" },
            transliteration = transliteration.ifBlank { title },
            translation = translation.ifBlank { "Custom Islamic Remembrance" },
            bengaliTranslation = "",
            defaultTarget = if (target > 0) target else 33,
            matchKeywords = keywordList.distinct(),
            isCustom = true,
            virtuInfo = "Personal custom Zikr phrase"
        )
    }
}
