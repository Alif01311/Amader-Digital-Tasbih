package com.example.data.repository

import com.example.data.local.CustomPhraseEntity
import com.example.data.local.TasbihDao
import com.example.data.local.TasbihSessionEntity
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

class TasbihRepository(private val dao: TasbihDao) {

    val allSessions: Flow<List<TasbihSessionEntity>> = dao.getAllSessions()
    val totalCount: Flow<Int?> = dao.getTotalCount()
    val customPhrases: Flow<List<CustomPhraseEntity>> = dao.getAllCustomPhrases()

    fun getTodayCount(): Flow<Int?> {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return dao.getTodayCount(calendar.timeInMillis)
    }

    suspend fun saveSession(
        phraseId: String,
        phraseTitle: String,
        count: Int,
        target: Int,
        mode: String,
        durationSeconds: Long = 0
    ): Long {
        if (count <= 0) return 0
        val session = TasbihSessionEntity(
            phraseId = phraseId,
            phraseTitle = phraseTitle,
            count = count,
            target = target,
            mode = mode,
            timestamp = System.currentTimeMillis(),
            durationSeconds = durationSeconds
        )
        return dao.insertSession(session)
    }

    suspend fun addCustomPhrase(
        title: String,
        arabicText: String,
        transliteration: String,
        translation: String,
        target: Int,
        keywords: String
    ): Long {
        val entity = CustomPhraseEntity(
            title = title,
            arabicText = arabicText,
            transliteration = transliteration,
            translation = translation,
            target = target,
            keywords = keywords
        )
        return dao.insertCustomPhrase(entity)
    }

    suspend fun deleteCustomPhrase(id: Long) {
        dao.deleteCustomPhrase(id)
    }

    suspend fun clearHistory() {
        dao.clearHistory()
    }
}
