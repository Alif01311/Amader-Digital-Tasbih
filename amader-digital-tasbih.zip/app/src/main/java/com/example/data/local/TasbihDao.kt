package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TasbihDao {

    @Query("SELECT * FROM tasbih_sessions ORDER BY timestamp DESC LIMIT 100")
    fun getAllSessions(): Flow<List<TasbihSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: TasbihSessionEntity): Long

    @Query("SELECT SUM(count) FROM tasbih_sessions")
    fun getTotalCount(): Flow<Int?>

    @Query("SELECT SUM(count) FROM tasbih_sessions WHERE timestamp >= :startOfDayTimestamp")
    fun getTodayCount(startOfDayTimestamp: Long): Flow<Int?>

    @Query("SELECT * FROM custom_phrases ORDER BY createdAt DESC")
    fun getAllCustomPhrases(): Flow<List<CustomPhraseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomPhrase(phrase: CustomPhraseEntity): Long

    @Query("DELETE FROM custom_phrases WHERE id = :id")
    suspend fun deleteCustomPhrase(id: Long)

    @Query("DELETE FROM tasbih_sessions")
    suspend fun clearHistory()
}
