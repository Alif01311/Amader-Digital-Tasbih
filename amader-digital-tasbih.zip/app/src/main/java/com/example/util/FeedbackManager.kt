package com.example.util

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

class FeedbackManager(context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val celebrationPlayer = CelebrationSoundPlayer(context)

    private var toneGenerator: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 45)
    } catch (e: Exception) {
        Log.e("FeedbackManager", "Failed to init ToneGenerator", e)
        null
    }

    fun triggerCountFeedback(vibrationEnabled: Boolean, soundEnabled: Boolean) {
        if (vibrationEnabled) {
            triggerVibration(durationMs = 30, amplitude = 120)
        }
        if (soundEnabled) {
            playClickSound()
        }
    }

    fun triggerTargetReachedFeedback(vibrationEnabled: Boolean, soundEnabled: Boolean) {
        if (vibrationEnabled) {
            triggerCelebrationVibration()
        }
        if (soundEnabled) {
            celebrationPlayer.playCongratulationChime()
        }
    }

    private fun triggerVibration(durationMs: Long, amplitude: Int) {
        try {
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val clampedAmplitude = amplitude.coerceIn(1, 255)
                    val effect = VibrationEffect.createOneShot(durationMs, clampedAmplitude)
                    vibrator.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(durationMs)
                }
            }
        } catch (e: Exception) {
            Log.e("FeedbackManager", "Vibration error", e)
        }
    }

    private fun triggerCelebrationVibration() {
        try {
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val timings = longArrayOf(0, 100, 80, 150, 80, 250)
                    val amplitudes = intArrayOf(0, 180, 0, 220, 0, 255)
                    val effect = VibrationEffect.createWaveform(timings, amplitudes, -1)
                    vibrator.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    val pattern = longArrayOf(0, 100, 80, 150, 80, 250)
                    vibrator.vibrate(pattern, -1)
                }
            }
        } catch (e: Exception) {
            Log.e("FeedbackManager", "Celebration vibration error", e)
        }
    }

    private fun playClickSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 35)
        } catch (e: Exception) {
            Log.e("FeedbackManager", "Sound error", e)
        }
    }

    private fun playCelebrationSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 250)
        } catch (e: Exception) {
            Log.e("FeedbackManager", "Sound error", e)
        }
    }

    fun release() {
        toneGenerator?.release()
        toneGenerator = null
    }
}
