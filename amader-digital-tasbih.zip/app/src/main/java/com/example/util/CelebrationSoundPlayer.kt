package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * High-fidelity congratulation chime player.
 * Synthesizes a celebratory ascending bell arpeggio (F4 -> A4 -> C5 -> F5)
 * with gentle exponential decay, providing an uplifting, soothing Islamic chime.
 */
class CelebrationSoundPlayer(private val context: Context) {

    private val TAG = "CelebrationSoundPlayer"
    private val scope = CoroutineScope(Dispatchers.Default)

    fun playCongratulationChime() {
        scope.launch {
            try {
                playSynthesizedArpeggio()
            } catch (e: Exception) {
                Log.e(TAG, "AudioTrack synthesis failed, falling back to system chime", e)
                playSystemFallback()
            }
        }
    }

    private fun playSynthesizedArpeggio() {
        val sampleRate = 44100
        // Ascending pentatonic / chord notes: F4, A4, C5, F5, A5
        val notes = doubleArrayOf(349.23, 440.00, 523.25, 698.46, 880.00)
        val noteDurationSec = 0.16
        val tailDurationSec = 0.90
        val totalDurationSec = (notes.size * noteDurationSec) + tailDurationSec
        val totalSamples = (sampleRate * totalDurationSec).toInt()

        val buffer = ShortArray(totalSamples)

        // Synthesize bell tones with warm harmonics & exponential decay
        notes.forEachIndexed { noteIndex, freq ->
            val startSample = (noteIndex * noteDurationSec * sampleRate).toInt()
            val remainingSamples = totalSamples - startSample

            for (i in 0 until remainingSamples) {
                val t = i.toDouble() / sampleRate
                // Bell envelope: sharp attack, exponential decay
                val envelope = exp(-3.2 * t)
                // Fundamental + octave harmonic (warm chime resonance)
                val wave1 = sin(2.0 * PI * freq * t)
                val wave2 = 0.4 * sin(4.0 * PI * freq * t)
                val wave3 = 0.2 * sin(6.0 * PI * freq * t)
                val sampleValue = (wave1 + wave2 + wave3) * envelope * 0.35

                val currentIdx = startSample + i
                if (currentIdx < totalSamples) {
                    val mixed = (buffer[currentIdx] + (sampleValue * Short.MAX_VALUE).toInt()).coerceIn(
                        Short.MIN_VALUE.toInt(),
                        Short.MAX_VALUE.toInt()
                    )
                    buffer[currentIdx] = mixed.toShort()
                }
            }
        }

        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        val trackBufferSize = buffer.size * 2
        val audioTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(trackBufferSize.coerceAtLeast(minBufferSize))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
        } else {
            @Suppress("DEPRECATION")
            AudioTrack(
                AudioManager.STREAM_MUSIC,
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                trackBufferSize.coerceAtLeast(minBufferSize),
                AudioTrack.MODE_STATIC
            )
        }

        audioTrack.write(buffer, 0, buffer.size)
        audioTrack.play()

        // Clean up track after completion
        Thread.sleep(((totalDurationSec + 0.3) * 1000).toLong())
        try {
            audioTrack.stop()
            audioTrack.release()
        } catch (e: Exception) {
            Log.e(TAG, "AudioTrack release error", e)
        }
    }

    private fun playSystemFallback() {
        try {
            val notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val ringtone = RingtoneManager.getRingtone(context, notificationUri)
            ringtone?.play()
        } catch (e: Exception) {
            try {
                val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
                tone.startTone(ToneGenerator.TONE_PROP_ACK, 400)
            } catch (ignored: Exception) {}
        }
    }
}
