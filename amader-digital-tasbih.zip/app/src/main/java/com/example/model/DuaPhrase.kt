package com.example.model

/**
 * Representation of a Tasbih / Dua recitation phrase with
 * Arabic calligraphy text, English transliteration, translations,
 * and speech recognition matching keywords.
 */
data class DuaPhrase(
    val id: String,
    val title: String,
    val arabicText: String,
    val transliteration: String,
    val translation: String,
    val bengaliTranslation: String,
    val defaultTarget: Int = 33,
    val matchKeywords: List<String>,
    val isCustom: Boolean = false,
    val virtuInfo: String = ""
) {
    companion object {
        val PRESET_PHRASES = listOf(
            DuaPhrase(
                id = "subhanallah",
                title = "Subhanallah",
                arabicText = "سُبْحَانَ اللَّهِ",
                transliteration = "Subhan Allah",
                translation = "Glory be to Allah",
                bengaliTranslation = "আল্লাহ পবিত্র ও মহামহিম",
                defaultTarget = 33,
                matchKeywords = listOf(
                    "subhanallah", "subhan allah", "sobhanallah", "sobhan allah", "subhan", "sobhan",
                    "subhana", "subhanal", "subana", "sovana", "sovanalla", "so banana", "soup on allah",
                    "সুবহানাল্লাহ", "সুবহান আল্লাহ", "সুবহান", "সবহানাল্লাহ", "সবহান",
                    "سُبْحَانَ", "سبحان الله", "سبحان", "سبحانك"
                ),
                virtuInfo = "Removes sins even if they are like the foam of the sea."
            ),
            DuaPhrase(
                id = "alhamdulillah",
                title = "Alhamdulillah",
                arabicText = "الْحَمْدُ لِلَّهِ",
                transliteration = "Alhamdulillah",
                translation = "Praise be to Allah",
                bengaliTranslation = "সকল প্রশংসা আল্লাহর জন্য",
                defaultTarget = 33,
                matchKeywords = listOf(
                    "alhamdulillah", "alhamdu lillah", "alhamdo lillah", "alhamdulilla", "alhamdullilah",
                    "alhamdu", "elhamdulillah", "elhamdu", "alham", "i'll hamdu", "al hamdu",
                    "আলহামদুলিল্লাহ", "আলহামদু লিল্লাহ", "আলহামদু", "হমদুলিল্লাহ",
                    "الحمد لله", "الحمد", "لله الحمد", "حمد"
                ),
                virtuInfo = "Fills the scale of good deeds with abundant reward."
            ),
            DuaPhrase(
                id = "allahu_akbar",
                title = "Allahu Akbar",
                arabicText = "اللَّهُ أَكْبَرُ",
                transliteration = "Allahu Akbar",
                translation = "Allah is the Greatest",
                bengaliTranslation = "আল্লাহ মহান",
                defaultTarget = 34,
                matchKeywords = listOf(
                    "allahu akbar", "allah akbar", "allah hu akbar", "allahuakbar", "akbar", "allaho akbar",
                    "allah hu akber", "allahu akber", "allah", "allahu",
                    "আল্লাহু আকবার", "আল্লাহ আকবার", "আল্লাহু", "আকবার",
                    "الله أكبر", "الله اكبر", "أكبر", "اكبر"
                ),
                virtuInfo = "The most beloved words to Allah."
            ),
            DuaPhrase(
                id = "astaghfirullah",
                title = "Astaghfirullah",
                arabicText = "أَسْتَغْفِرُ اللَّهَ",
                transliteration = "Astaghfirullah",
                translation = "I seek forgiveness from Allah",
                bengaliTranslation = "আমি আল্লাহর নিকট ক্ষমা প্রার্থনা করছি",
                defaultTarget = 100,
                matchKeywords = listOf(
                    "astaghfirullah", "astagfirullah", "astaqfirullah", "astaghfir", "astagfir", "astegferullah",
                    "astagfurullah", "astagfirulla", "astag", "istighfar", "istigfar", "astegfirullah",
                    "আস্তাগফিরুল্লাহ", "আস্তাগফিরুল্লাহিল", "আস্তাগফির", "ইস্তেগফার",
                    "أستغفر الله", "استغفر الله", "استغفر", "أستغفر"
                ),
                virtuInfo = "Opens the doors of sustenance, relief, and forgiveness."
            ),
            DuaPhrase(
                id = "la_ilaha_illallah",
                title = "La Ilaha Illallah",
                arabicText = "لَا إِلٰهَ إِلَّا اللَّهُ",
                transliteration = "La ilaha illallah",
                translation = "There is no deity worthy of worship except Allah",
                bengaliTranslation = "আল্লাহ ব্যতীত কোনো সত্য উপাস্য নেই",
                defaultTarget = 100,
                matchKeywords = listOf(
                    "la ilaha illallah", "la ilaha illa allah", "la ilaha illalla", "lailahaillallah",
                    "la ilaha", "illa allah", "illallah", "ilaha illallah", "lailaha",
                    "লা ইলাহা ইল্লাল্লাহ", "লা ইলাহা", "ইল্লাল্লাহ",
                    "لا إله إلا الله", "لا اله الا الله", "لا إله", "إلا الله"
                ),
                virtuInfo = "The best phrase of remembrance and key to Jannah."
            ),
            DuaPhrase(
                id = "subhanallahi_wa_bihamdihi",
                title = "Subhanallahi wa Bihamdihi",
                arabicText = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
                transliteration = "Subhanallahi wa bihamdihi",
                translation = "Glory be to Allah and all praise is His",
                bengaliTranslation = "আল্লাহর পবিত্রতা ঘোষণা করছি এবং তাঁরই প্রশংসা",
                defaultTarget = 100,
                matchKeywords = listOf(
                    "subhanallahi wa bihamdihi", "subhan allah wa bihamdihi", "subhanallah bihamdihi",
                    "সুবহানাল্লাহি ওয়া বিহামদিহি", "سبحان الله وبحمده"
                ),
                virtuInfo = "Whoever recites this 100 times a day, their sins will be forgiven."
            ),
            DuaPhrase(
                id = "salawat_durud",
                title = "Durood Sharif (Salawat)",
                arabicText = "اللَّهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّدٍ",
                transliteration = "Allahumma Salli 'Ala Muhammad",
                translation = "O Allah, send blessings upon our Prophet Muhammad",
                bengaliTranslation = "হে আল্লাহ, আমাদের নবী মুহাম্মদের প্রতি শান্তি বর্ষণ করুন",
                defaultTarget = 100,
                matchKeywords = listOf(
                    "allahumma salli ala muhammad", "sallallahu alaihi wa sallam", "allahumma salli", "darood", "durood",
                    "সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম", "আল্লাহুম্মা সাল্লি", "اللهم صل على محمد", "صلى الله عليه وسلم"
                ),
                virtuInfo = "Whoever sends blessings once, Allah rewards them tenfold."
            ),
            DuaPhrase(
                id = "la_hawla",
                title = "La Hawla Wa La Quwwata",
                arabicText = "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
                transliteration = "La hawla wa la quwwata illa billah",
                translation = "There is no might nor power except with Allah",
                bengaliTranslation = "আল্লাহর সাহায্য ছাড়া পাপ থেকে বাঁচার ও নেক কাজ করার শক্তি নেই",
                defaultTarget = 33,
                matchKeywords = listOf(
                    "la hawla wa la quwwata illa billah", "la hawla", "lahawla", "illa billah",
                    "লা হাওলা ওয়ালা কুওয়াতা", "لا حول ولا قوة إلا بالله"
                ),
                virtuInfo = "A treasure from beneath the Throne of Allah."
            ),
            DuaPhrase(
                id = "hasbunallah",
                title = "Hasbunallahu Wa Ni'mal Wakeel",
                arabicText = "حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ",
                transliteration = "Hasbunallahu wa ni'mal wakeel",
                translation = "Allah is sufficient for us, and He is the best Disposer of affairs",
                bengaliTranslation = "আল্লাহই আমাদের জন্য যথেষ্ট এবং তিনি উত্তম কর্মবিধায়ক",
                defaultTarget = 100,
                matchKeywords = listOf(
                    "hasbunallah", "hasbunallahu", "hasbi allah", "nimal wakeel",
                    "হাসবুনাল্লাহু", "حسبنا الله ونعم الوكيل"
                ),
                virtuInfo = "Protection and peace in times of hardship and anxiety."
            )
        )
    }
}
