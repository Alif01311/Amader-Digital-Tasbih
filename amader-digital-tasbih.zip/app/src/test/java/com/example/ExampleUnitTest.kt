package com.example

import com.example.model.DuaPhrase
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun presets_areNotEmpty() {
        val presets = DuaPhrase.PRESET_PHRASES
        assertTrue(presets.isNotEmpty())
        assertEquals(9, presets.size)
    }

    @Test
    fun subhanallahPreset_hasValidKeywords() {
        val subhanallah = DuaPhrase.PRESET_PHRASES.first { it.id == "subhanallah" }
        assertEquals(33, subhanallah.defaultTarget)
        assertTrue(subhanallah.matchKeywords.contains("subhanallah"))
        assertTrue(subhanallah.matchKeywords.contains("সুবহানাল্লাহ"))
    }

    @Test
    fun allahuAkbarPreset_hasTarget34() {
        val allahuAkbar = DuaPhrase.PRESET_PHRASES.first { it.id == "allahu_akbar" }
        assertEquals(34, allahuAkbar.defaultTarget)
        assertTrue(allahuAkbar.matchKeywords.contains("allahu akbar"))
    }
}
